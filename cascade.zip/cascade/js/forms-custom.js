// jQuery $('document').ready(); function 
$('document').ready(function(){

	$('#pulser').pulsate({
		color : '#54728c'
	});
	
	$('#pulsateSuccess').pulsate({
			color : '#468845'
		});
	
	$('#pulsateDanger').pulsate({
			color : '#B94A48'
		});
	
	$('#pulsateWarning').pulsate({
			color : '#C09853'
		});

});