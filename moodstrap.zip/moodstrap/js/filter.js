(function ($) {
  jQuery.expr[':'].Contains = function(a,i,m){
      return (a.textContent || a.innerText || "").toUpperCase().indexOf(m[3].toUpperCase())>=0;
  };
 
  function filterList(header, slist) {
    var form = $("<form>").attr({"class":"filterform form-search","action":"#"}),
        input = $("<input>").attr({"class":"filterinput form-control","placeholder":"Type to Filter","type":"text"});
    $(form).append(input).appendTo(header);
 
    $(input)
      .change( function () {
        var filter = $(this).val();
        if(filter) {
 
          $matches = $(slist).find('a:Contains(' + filter + ')').parent();
          $('li', slist).not($matches).slideUp();
          $matches.slideDown();
 
        } else {
          $(slist).find("li").slideDown(200);
        }
        return false;
      })
    .keyup( function () {
        $(this).change();
    });
  }
 
  $(function () {
    filterList($("#form"), $("#slist"));
  });
}(jQuery));